/** @type {import('next').NextConfig} */
const nextConfig = {
  // Static export for deployment
  output: 'export',

  // Disable image optimization for static export
  images: {
    unoptimized: true,
  },

  // Add trailing slashes for better static hosting
  trailingSlash: true,

  // Skip build-time errors
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;